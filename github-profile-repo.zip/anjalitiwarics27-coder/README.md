<div align="center">

<img src="assets/banner.svg" alt="Anjali Tiwari - Full-Stack Developer | AI/ML Enthusiast" width="100%"/>

<a href="https://git.io/typing-svg">
  <img src="https://readme-typing-svg.demolab.com?font=Fira+Code&weight=600&size=22&pause=1000&color=A78BFA&center=true&vCenter=true&width=650&lines=Hi%2C+I'm+Anjali+%F0%9F%91%8B;CSE+Student+%7C+Full-Stack+%7C+AI%2FML;Building+AI-powered+full-stack+apps;Open+to+Internships+%F0%9F%9A%80" alt="Typing SVG" />
</a>

<img src="assets/hero-character.svg" alt="Coding illustration" width="75%"/>

<br/>

![Profile Views](https://komarev.com/ghpvc/?username=anjalitiwarics27-coder&label=PROFILE%20VIEWS&color=6a11cb&style=flat-square)
![Followers](https://img.shields.io/github/followers/anjalitiwarics27-coder?label=FOLLOWERS&style=flat-square&color=2575fc&logo=github)
![Stars](https://img.shields.io/github/stars/anjalitiwarics27-coder?label=STARS&style=flat-square&color=f59e0b&logo=github)
![CGPA](https://img.shields.io/badge/CGPA-8.3-22c55e?style=flat-square)
![Open To](https://img.shields.io/badge/OPEN%20TO-INTERNSHIPS-ec4899?style=flat-square)

<br/>

[![About](https://img.shields.io/badge/ABOUT-4c1d95?style=for-the-badge)](#-about-me)
[![Experience](https://img.shields.io/badge/EXPERIENCE-6d28d9?style=for-the-badge)](#-experience)
[![Skills](https://img.shields.io/badge/SKILLS-2563eb?style=for-the-badge)](#-tech-stack)
[![Projects](https://img.shields.io/badge/PROJECTS-db2777?style=for-the-badge)](#-featured-projects-auto-updated)
[![Certifications](https://img.shields.io/badge/CERTIFICATIONS-d97706?style=for-the-badge)](#-certifications)
[![Stats](https://img.shields.io/badge/STATS-ea580c?style=for-the-badge)](#-github-stats)
[![Contact](https://img.shields.io/badge/CONTACT-ec4899?style=for-the-badge)](#-contact)

</div>

<img src="assets/divider.svg" width="100%" alt=""/>

## 👩‍💻 About Me

<div align="center">
  <img src="assets/about-card.svg" alt="About Anjali Tiwari" width="100%"/>
</div>

<details>
<summary>✨ A few more things about me (click to open)</summary>
<br/>

- 🎯 I enjoy turning ideas into working products end-to-end
- 🐘 I've worked on wildlife conservation using computer vision
- 📚 Currently strengthening DSA & core CS fundamentals

</details>

<img src="assets/divider.svg" width="100%" alt=""/>

## 💼 Experience

<div align="center">
  <img src="assets/experience-timeline.svg" alt="Internship Journey 2026" width="100%"/>
</div>

<br/>

### 🟢 Software Development Intern (Python)

**DigiSamaksh Private Limited** &nbsp;·&nbsp; ![Duration](https://img.shields.io/badge/Jun_1_--_Aug_10%2C_2026-6d28d9?style=flat-square) ![Python](https://img.shields.io/badge/Python-3776AB?style=flat-square&logo=python&logoColor=white) ![NumPy](https://img.shields.io/badge/NumPy-013243?style=flat-square&logo=numpy&logoColor=white) ![Pandas](https://img.shields.io/badge/Pandas-150458?style=flat-square&logo=pandas&logoColor=white) ![Git](https://img.shields.io/badge/Git-F05032?style=flat-square&logo=git&logoColor=white)

> - 🎯 Designed and built a **job-portal recommendation engine** in Python using similarity-matching to rank candidates against listings by skills & experience
> - 🧹 Cleaned, preprocessed and analysed candidate/job data with **NumPy & Pandas**, improving match relevance
> - 🔄 Owned features end-to-end in an **Agile** workflow: development, debugging, testing, **Git/GitHub** and code review before delivery

<br/>

### 🐘 Research Intern (AI/ML)

**Wildlife Institute of India** &nbsp;·&nbsp; ![Duration](https://img.shields.io/badge/Mar_--_Apr_2026-6d28d9?style=flat-square) ![Python](https://img.shields.io/badge/Python-3776AB?style=flat-square&logo=python&logoColor=white) ![OpenCV](https://img.shields.io/badge/OpenCV-5C3EE8?style=flat-square&logo=opencv&logoColor=white) ![CNN](https://img.shields.io/badge/CNN-ec4899?style=flat-square)

> - 🧠 Built, trained and tested a **Convolutional Neural Network (CNN)** in Python to identify individual elephants from photographs, enabling counting and photo-based tracking
> - 🖼️ Preprocessed and augmented image datasets using **Python, NumPy & OpenCV** to improve accuracy and generalisation

<br/>

### 🌐 Full Stack Developer Intern

**EduSkills Virtual Internship (AICTE)** &nbsp;·&nbsp; ![Duration](https://img.shields.io/badge/Jan_--_Mar_2026-6d28d9?style=flat-square) ![Grade](https://img.shields.io/badge/%F0%9F%8F%86_Grade_O-Outstanding-d97706?style=flat-square) ![HTML](https://img.shields.io/badge/HTML-E34F26?style=flat-square&logo=html5&logoColor=white) ![CSS](https://img.shields.io/badge/CSS-1572B6?style=flat-square&logo=css3&logoColor=white) ![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=flat-square&logo=javascript&logoColor=black)

> - ✅ Completed a **10-week Full Stack internship** (National Internship Portal, with IILM University)
> - 🎨 Built front-end features using **HTML, CSS, JavaScript & REST API integration**, following SDLC practices

<img src="assets/divider.svg" width="100%" alt=""/>

## 🧰 Tech Stack

<div align="center">

| Category | Technologies |
|:---|:---|
| **Languages** | <img src="https://skillicons.dev/icons?i=js,ts,py,c,cpp,java,html,css&perline=8" /> |
| **Front-End** | <img src="https://skillicons.dev/icons?i=react,nextjs,tailwind,bootstrap,vite&perline=8" /> |
| **Back-End** | <img src="https://skillicons.dev/icons?i=nodejs,express,flask,fastapi&perline=8" /> ![REST API](https://img.shields.io/badge/REST_API-ec4899?style=flat-square) ![JWT Auth](https://img.shields.io/badge/JWT_AUTH-ec4899?style=flat-square) |
| **Databases** | <img src="https://skillicons.dev/icons?i=mysql,postgres,mongodb,sqlite&perline=8" /> |
| **Data & AI/ML** | <img src="https://skillicons.dev/icons?i=tensorflow,pytorch,sklearn,opencv,pandas,numpy&perline=8" /> ![Streamlit](https://img.shields.io/badge/STREAMLIT-ff4b4b?style=flat-square&logo=streamlit&logoColor=white) |
| **Testing & Tools** | <img src="https://skillicons.dev/icons?i=postman,git,github,vscode,linux,aws&perline=8" /> |
| **Core CS** | ![DSA](https://img.shields.io/badge/DSA-4c1d95?style=flat-square) ![OOP](https://img.shields.io/badge/OOP-4c1d95?style=flat-square) ![OS](https://img.shields.io/badge/OS-4c1d95?style=flat-square) ![DBMS](https://img.shields.io/badge/DBMS-4c1d95?style=flat-square) ![CN](https://img.shields.io/badge/Computer_Networks-4c1d95?style=flat-square) |

<br/>

<img src="assets/skills.svg" alt="Skill proficiency" width="80%"/>

</div>

<img src="assets/divider.svg" width="100%" alt=""/>

## 🚀 Featured Projects <sub>(auto-updated)</sub>

<!--START_SECTION:projects-->
<!--END_SECTION:projects-->

<img src="assets/divider.svg" width="100%" alt=""/>

## 🏅 Certifications

| 🎓 Certification | 🏢 Issuer | 🗓️ Date | 🏆 Result |
|:---|:---|:---:|:---:|
| Full Stack Developer Virtual Internship (10 weeks) | EduSkills · AICTE · IILM University | Jan – Mar 2026 | **Grade O (Outstanding)** |
| *Add your next certificate here* | | | |

<img src="assets/divider.svg" width="100%" alt=""/>

## ⚡ Recent Activity <sub>(auto-updated)</sub>

<!--START_SECTION:activity-->
<!--END_SECTION:activity-->

<img src="assets/divider.svg" width="100%" alt=""/>

## 📈 GitHub Stats

<div align="center">

<!--START_SECTION:summary-->
<!--END_SECTION:summary-->

<br/><br/>

<img height="170" src="https://github-readme-stats.vercel.app/api?username=anjalitiwarics27-coder&show_icons=true&theme=radical&hide_border=true&include_all_commits=true" />
<img height="170" src="https://github-readme-stats.vercel.app/api/top-langs/?username=anjalitiwarics27-coder&layout=compact&theme=radical&hide_border=true" />

<br/>

<img src="https://streak-stats.demolab.com?user=anjalitiwarics27-coder&theme=radical&hide_border=true" />

<br/><br/>

<img src="https://leetcard.jacoblin.cool/anjalitiwari31?theme=dark&font=Fira%20Code&ext=heatmap" />

<br/><br/>

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/anjalitiwarics27-coder/anjalitiwarics27-coder/output/github-snake-dark.svg" />
  <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/anjalitiwarics27-coder/anjalitiwarics27-coder/output/github-snake.svg" />
  <img alt="Contribution snake" src="https://raw.githubusercontent.com/anjalitiwarics27-coder/anjalitiwarics27-coder/output/github-snake.svg" />
</picture>

</div>

<img src="assets/divider.svg" width="100%" alt=""/>

## 💬 Dev Quote of the Moment

<div align="center">
  <img src="https://quotes-github-readme.vercel.app/api?type=horizontal&theme=radical" />
</div>

<img src="assets/divider.svg" width="100%" alt=""/>

## 📫 Contact

<div align="center">

[![Email](https://img.shields.io/badge/Email-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:anjali.tiwari.cs27@iilm.edu)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://linkedin.com/in/YOUR_LINKEDIN_ID)
[![LeetCode](https://img.shields.io/badge/LeetCode-FFA116?style=for-the-badge&logo=leetcode&logoColor=black)](https://leetcode.com/u/anjalitiwari31/)
[![GeeksforGeeks](https://img.shields.io/badge/GeeksforGeeks-2F8D46?style=for-the-badge&logo=geeksforgeeks&logoColor=white)](https://www.geeksforgeeks.org/profile/anjalitiwari31)
[![Portfolio](https://img.shields.io/badge/Portfolio-6a11cb?style=for-the-badge&logo=vercel&logoColor=white)](https://anjali-portfolio-21.vercel.app/)

<br/>

<img src="assets/footer.svg" alt="Let's build something together" width="100%"/>

<br/>

<!--START_SECTION:updated-->
<!--END_SECTION:updated-->

</div>
